-- DropIndex
DROP INDEX "Offline_Appointment_doctorId_key";

-- DropIndex
DROP INDEX "Offline_Appointment_patientId_key";
