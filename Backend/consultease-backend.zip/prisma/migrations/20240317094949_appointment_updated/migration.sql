-- AlterTable
ALTER TABLE "Offline_Appointment" ADD COLUMN     "feedback" DOUBLE PRECISION;
