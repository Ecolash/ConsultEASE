-- AlterTable
ALTER TABLE "Doctor" ADD COLUMN     "medical_certificate" TEXT,
ADD COLUMN     "profile_pic" TEXT;

-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "profile_pic" TEXT;
