-- AlterTable
ALTER TABLE "Doctor" ADD COLUMN     "mobile" TEXT;

-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "mobile" TEXT;
