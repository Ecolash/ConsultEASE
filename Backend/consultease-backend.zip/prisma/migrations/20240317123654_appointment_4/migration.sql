-- AlterTable
ALTER TABLE "Offline_Appointment" ALTER COLUMN "appointment_time" SET DATA TYPE TEXT;
